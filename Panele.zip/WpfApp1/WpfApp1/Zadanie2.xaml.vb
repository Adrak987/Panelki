﻿Public Class Zadanie2

End Class
